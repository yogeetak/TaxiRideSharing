-- Sequence of items
-- Ordered, but have to loop through items to check for inclusion.
-- Currently the same as a table.


function Sequence(source)
  return source
end

return Sequence